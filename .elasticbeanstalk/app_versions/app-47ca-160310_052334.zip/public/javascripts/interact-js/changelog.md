## v2.0.0

Angle is now reported as straight up being 0deg, left being -90deg, right being 90 deg, etc..

getMoveDelta now uses lastStart if there is only one move.